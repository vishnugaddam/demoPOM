package dashboard;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import base.Log;
import oracle.jdbc.pool.OracleDataSource;

public class DashBoard_DB {
	
	//DataBase Connection 
			public  final static String DB_URL="jdbc:oracle:thin:@192.168.10.18:1521:xtdocqa";
			public  final static String DB_USERNAME="xtdocs";
			public  final static String DB_PASSWORD="xtdqaxtdocs16";
			
			public  static Connection con;
			public final String instanceName="NCH Europe";
			public final String clientName="NCH UK";

			 static  {
				OracleDataSource ds = null;
				try {
					Log.info("Database connection is going to establish");
					ds = new OracleDataSource();
					ds.setURL(DB_URL);
					con= ds.getConnection(DB_USERNAME, DB_PASSWORD);
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
			/**
			 * This Method To Close the DataBase Connection
			 */
			public  static void dbConnectionClose() throws SQLException
			{
				con.close();
				Log.info("DataBase Connection is Closed");
			}
			/**To get the my documents document count based on status 
			 * @return 
			 * @throws SQLException */
				public String getDocCount(String status, String userName) throws SQLException{			
					
					String stmt="SELECT COUNT (DISTINCT D.XTG_DOCUMENT_ID) AS DOCS FROM DOCUMENT D LEFT JOIN PAYABLES_DISTRIBUTION PD ON D.XTG_DOCUMENT_ID=PD.XTG_DOCUMENT_ID "
							+ "JOIN CLIENT_INSTANCE_MASTER CIM ON CIM.CLIENT_INSTANCE_ID=D.CLIENT_INSTANCE_ID JOIN INSTANCE_DOCUMENT_STATUS IDS ON IDS.STATUS_ID=D.STATUS_ID JOIN MESSAGE_LIBRARY_MASTER MLM ON MLM.MESSAGE_CODE=IDS.STATUS_DISPLAY_NAME "
							+ "JOIN CLIENT_MASTER CM ON CM.CLIENT_ID=D.CLIENT_ID LEFT JOIN USER_AUTHENTICATION UA ON (UA.USER_ID=PD.ASSIGNED_TO_ID OR UA.USER_ID=D.ASSIGNED_TO_ID) WHERE CIM.INSTANCE_NAME='"+instanceName+"' AND CM.CLIENT_NAME='"+clientName+"' AND "
							+ "D.ACTIVE_FLAG='Y' AND D.REJECTED_FLAG IN ('N') AND MLM.MESSAGE_TEXT IN ('"+status+"') AND ((D.ASSIGNED_TO_GROUP='AP' OR D.ASSIGNED_TO_GROUP='"+userName+"') OR UA.EMAIL_ID='"+userName+"') ";
				PreparedStatement ps=con.prepareStatement(stmt);
				ResultSet rs=ps.executeQuery();
				String rs1 = null;
				if(rs.next()){
					 rs1=rs.getString("DOCS");
				}
				System.out.println(rs1);
				return rs1;
				
				}

}
