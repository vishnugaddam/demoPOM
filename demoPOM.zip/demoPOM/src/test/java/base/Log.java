package base;

import org.apache.log4j.Logger;

public class Log {

	//Initialize Log4j logs
	public static Logger Log = Logger.getLogger(Log.class.getName());//
	
			
	// Need to create these methods, so that they can be called  
	public static void info(String message) {
		Log.info(message);
		
	}
	public static void info(Exception e) {
		Log.info(e);
	}
	public static void startTest(String message){
		Log.info("Test Case Start: "+message);
	}
	public static void endTest(String message){
		Log.info("Test Case End: "+message);
	}

	public static void warn(String message) {
		Log.warn(message);
	}

	public static void error(String message) {
		Log.error(message);
	}

	public static void fatal(String message) {
		Log.fatal(message);
	}

	public static void debug(String message) {
		Log.debug(message);
	}
	
	public static void getExceptionMessge(Exception e) {
		Log.error(e);
	}

}