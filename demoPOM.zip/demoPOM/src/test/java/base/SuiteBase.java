package base;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;

import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import dashboard.DashBoard_DB;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;
import utility.Xls_Reader;
import webDriver.WebPage;

public class SuiteBase {
	public static ExtentTest test;
	public static ExtentReports erport;
	
	@BeforeSuite
	@Parameters({"Browser"})
	public void beforsuite(String Browser){
		String workdir=System.getProperty("user.dir");
		erport=new ExtentReports(workdir+"\\report"+"\\Report.html");
		erport.loadConfig(new File(workdir+"\\configFiles"+"\\extent-config.xml"));
		Map<String,String> sysInfo = new HashMap<String,String>();
		sysInfo.put("Environment", "QA");
		sysInfo.put("Browser Name", Browser);
		erport.addSystemInfo(sysInfo);
		DOMConfigurator.configure(workdir+"\\configFiles"+"\\log4j.xml");
	}
	
	@AfterSuite
	public void aftersuite() throws Exception{
		erport.endTest(test);
		erport.flush();
		MailSetup.SendEmail();
		WebPage.wait(3);
		WebPage.closeBrowser();
		DashBoard_DB.dbConnectionClose();
	}
	public void openBrowser (String browser, String url) throws IOException{		
		WebPage.openBrowser(browser,url);
	}
	public String getMethodName(){
		String method=new Exception().getStackTrace()[1].getMethodName();
		return method;
	}
	public boolean skip_Test(Xls_Reader xls_obj,String sheetName,String testCase_ID){
		boolean isSkip=false;
		int rowNumber=xls_obj.getFirstDataRowNum(sheetName, "TCID", testCase_ID);
		String runMode=xls_obj.getCellData(sheetName, "Run", rowNumber);
		if(runMode.contentEquals("No")|| runMode.isEmpty()){
			isSkip=true;
		}
		else{
			isSkip=false;
		}
		return isSkip;

	}
	public void startTest(String testCase_ID,String TCDesc,String ClassName){
		test = erport.startTest(testCase_ID+": "+TCDesc);
		test.log(LogStatus.INFO,"Scenario: "+ TCDesc);
		test.assignCategory(ClassName);	
		Log.startTest(testCase_ID);	
	}
	public void tryBlock(Xls_Reader xls_obj,String sheetName,String testCase_ID,String description){
		int rowNumber=xls_obj.getFirstDataRowNum(sheetName, "TCID", testCase_ID);
		xls_obj.setCellData(sheetName, "Test_Status", rowNumber, "PASS");
		test.log(LogStatus.PASS, description);
		erport.endTest(test);
		Log.endTest(testCase_ID);
	}

	public void catchBlock(Xls_Reader xls_obj,String sheetName,Exception e,String testCase_ID) throws Exception{

		int rowNumber=xls_obj.getFirstDataRowNum(sheetName, "TCID", testCase_ID);
		xls_obj.setCellData(sheetName, "Test_Status", rowNumber, "FAIL");
		test.log(LogStatus.FAIL, e.getMessage());		
		takeScreenShot(testCase_ID);	
		erport.endTest(test);
		Log.getExceptionMessge(e);
		Log.endTest(testCase_ID);
	}
	
	public  File getScreenshotFolder(){
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy") ;
		String curDate =dateFormat.format(date);
		String dest=System.getProperty("user.dir")+"\\ScreenShots\\";			
		File Path = new File(dest+curDate);
		Path.mkdir();
		return Path;	
	}

	public  String currentDateTime()
	{
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy,HH-mm");
		String formattedDate = sdf.format(date);
		formattedDate.toString();
		return formattedDate;
	}
	public String takeScreenShot(String tcID) throws Exception
	{
		File path=getScreenshotFolder();
		String time=currentDateTime();
		String dest=path+"//"+tcID+"_"+time+".png";
		Screenshot screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(WebPage.d);
		ImageIO.write(screenshot.getImage(), "PNG", new File(dest));								
		String image= test.addScreenCapture(dest);
		test.log(LogStatus.FAIL, "Testcase Failed", image);
		return dest;
	}
}
