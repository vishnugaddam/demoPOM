package webDriver;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebPage {
	
	public static WebDriver d;
	
	public static void openBrowser(String Browser,String url) throws IOException {
	if(Browser.contentEquals("chrome"))
	{

		String ChromePath = "drivers/chromedriver.exe";
		System.setProperty("webdriver.chrome.driver",ChromePath);
		//downloadFilepath = System.getProperty("user.dir")+"\\Download\\";
		//downloadFilepath = "//192.168.1.193//Circulus_Enterprise//TestData//";
		HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
		chromePrefs.put("profile.default_content_settings.popups", 0);
		//chromePrefs.put("download.default_directory", downloadFilepath);
		ChromeOptions options = new ChromeOptions();
		HashMap<String, Object> chromeOptionsMap = new HashMap<String, Object>();
		options.setExperimentalOption("prefs", chromePrefs);
		options.addArguments("disable-infobars");
		options.addArguments("--test-type");
		DesiredCapabilities cap = DesiredCapabilities.chrome();
		cap.setCapability(ChromeOptions.CAPABILITY, chromeOptionsMap);
		cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		cap.setCapability(ChromeOptions.CAPABILITY, options);   
		d = new ChromeDriver();
		d.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS) ;
		d.get(url);
		d.manage().window().maximize();

	}
	else if(Browser.contentEquals("Firefox"))  {
		String FirePath = "drivers/geckodriver.exe";
		System.setProperty("webdriver.gecko.driver",FirePath);

		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setCapability("marionette",true);		

		d=new FirefoxDriver();
		d.manage().window().maximize();
		d.get(url);
	}
	else if (Browser.contentEquals("IE")){

		String IEPath = "drivers/IEDriverServer.exe";
		System.setProperty("webdriver.ie.driver",IEPath);	

		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();	

		capabilities.setCapability(CapabilityType.BROWSER_NAME, "IE");
		capabilities.setCapability(InternetExplorerDriver.
				INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);	
		capabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
		capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
		capabilities.setCapability("allow-blocked-content", true);
		capabilities.setCapability("allowBlockedContent", true);
		// Define options.
		//InternetExplorerOptions ieOptions = new InternetExplorerOptions();
		// ieOptions.takeFullPageScreenshot();
		//TakesScreenshot screenShot = ((TakesScreenshot)d);
		//File srcfile = screenShot.getScreenshotAs(OutputType.FILE);
		//FileUtils.copyFile(srcfile,new File("E:\\Automation\\Enterprise_Prod\\ScreenShots"));
		d=new InternetExplorerDriver();
		d.manage().window().maximize();
		d.get(url);
	}
}
	public static String getText(By obj){		
		WebDriverWait wait = new WebDriverWait(d, 10);
		WebElement el=wait.until(ExpectedConditions.visibilityOfElementLocated(obj));
		return el.getText();

}
	
	public static void click(By obj){

		WebDriverWait wait = new WebDriverWait(d, 10);
		WebElement el=wait.until(ExpectedConditions.visibilityOfElementLocated(obj));
		el.click();
	}
	
	public static void sendKeys(By obj, String data){
		WebDriverWait wait = new WebDriverWait(d, 10);
		//scrollBarHandle(obj);
		WebElement el=wait.until(ExpectedConditions.visibilityOfElementLocated(obj));
		el.clear();
		wait(2);
		el.sendKeys(data);
}
	public static void wait(int sleeptime){

		try {
			Thread.sleep(sleeptime*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void closeBrowser(){

		d.close();
	}
	public static String getPageTitle(){

		return d.getTitle();
	}
}