package utility;

import java.util.HashMap;
import java.util.Map;

public class TestData {
	
		//Workbook name
		public final String demoWorkBook="TestData.xlsx";
		
		//excel file object
		public Xls_Reader demo_xlx=null;
		String UserName;
		String Password;		
		
		public TestData(){
			
			String testdataDir=System.getProperty("user.dir")+"//testDataFile";
			String TDPath=testdataDir+"//"+demoWorkBook;
			System.out.println("TDPath: "+TDPath);
			demo_xlx=new Xls_Reader(TDPath);
		}
		
		public final  String col_TestCaseID="TCID";
		public final String col_TCDescription="Test Script Description";
		
		public final  String col_UserName="UserName";
		public final  String col_PassWord="Password";
		public final String col_AppCount="ApprovalCount";
		public final String col_PageTitle="PageTitle";
		public final String col_Status="Status";
		
		public int getTestCaseRowRumberinExcel(Xls_Reader xls_obj,String sheetName,String MethodName)
		{	
			return xls_obj.getFirstDataRowNum(sheetName, col_TestCaseID, MethodName);
		}
		public int getTestcaseStartNumber(Xls_Reader xls_obj,String sheetName,String MethodName){
			return xls_obj.getFirstDataRowNum(sheetName, col_TestCaseID, MethodName);
		}
		public int getTestCaseEndNumber(Xls_Reader xls_obj,String sheetName,String MethodName,int row){
			return xls_obj.getLastDataRowNum(sheetName, col_TestCaseID, MethodName, row);
		}
		public String getTCDescription(Xls_Reader xls_obj,String sheetName,String method){
			int rowNum=getTestCaseRowRumberinExcel(xls_obj,sheetName,method);
			return xls_obj.getCellData(sheetName, col_TCDescription, rowNum);
		}
		
		
		public void setLoginData(Xls_Reader xls_obj,String sheetName,String method)
		{	System.out.println(sheetName);
			int row=getTestCaseRowRumberinExcel(xls_obj,sheetName,method);
			UserName=xls_obj.getCellData(sheetName, col_UserName, row);
			Password=xls_obj.getCellData(sheetName, col_PassWord, row);
			System.out.println(UserName);
			System.out.println(Password);

		}

		public String getUserName(){
			return UserName;
		}

		public String getPassword(){
			return Password;
		}
	
		
		//To get the test data from excel file
		public Map<String,String> getTestData(Xls_Reader xls_obj, String sheetName,String testCaseID){
			Map<String,String> testdata;
			testdata=new HashMap<String,String>();
			int rowNum=getTestCaseRowRumberinExcel(xls_obj,sheetName, testCaseID);

			testdata.put(col_UserName, xls_obj.getCellData(sheetName,col_UserName, rowNum));
			testdata.put(col_PassWord, xls_obj.getCellData(sheetName,col_PassWord, rowNum));
			testdata.put(col_AppCount, xls_obj.getCellData(sheetName,col_AppCount, rowNum));
			testdata.put(col_PageTitle, xls_obj.getCellData(sheetName, col_PageTitle, rowNum));
			testdata.put(col_Status, xls_obj.getCellData(sheetName, col_Status, rowNum));
			return testdata;
		}
}
