package login;

import java.io.IOException;

import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import actions.Common_Methods;
import actions.Login_PageActions;
import base.SuiteBase;
import utility.TestData;
import utility.Xls_Reader;
import webDriver.WebPage;

public class Login_01 extends SuiteBase{
	Xls_Reader xls_obj;
	String Sheet_TC;
	String Sheet_TD;
	String ClassName;
	TestData obj_TD;
	Common_Methods obj_CM;
	Login_PageActions obj_LPA;
	
	@BeforeClass
	@Parameters({"Browser","URL"})
	public void login(String Browser,String URL) throws IOException{
		
		obj_TD=new TestData();
		xls_obj=obj_TD.demo_xlx;
		obj_LPA=new Login_PageActions();
		obj_CM=new Common_Methods();
		
		openBrowser(Browser,URL);
		
		ClassName= this.getClass().getSimpleName();	//used to get the current class name
		String methodName=getMethodName();
		
		Sheet_TC=obj_LPA.sheet_TestCases;
		Sheet_TD=obj_LPA.sheet_TestData;
		
		obj_TD.setLoginData(xls_obj,Sheet_TD,methodName);
		obj_CM.login(obj_TD.getUserName(), obj_TD.getPassword());
	}
	
	/**To verify the dash board page title after user login to the portal successfully 
	 * @throws Exception */
	@Test
	public void Demo_TC_001() throws Exception{
		String testCase_ID=getMethodName();
		boolean isSkip=false;
		boolean flag=false;
		
		try{
			isSkip=skip_Test(xls_obj, Sheet_TC, testCase_ID);	
		if(isSkip){
			throw new SkipException("Skip this TestCase");
		}
		
		String TCDesc=obj_TD.getTCDescription(xls_obj, Sheet_TC, testCase_ID);
		startTest(testCase_ID,TCDesc,ClassName);
		
		flag=obj_CM.pageTitleVerification(xls_obj, Sheet_TD, testCase_ID);
		
		if(flag){
			tryBlock(xls_obj, Sheet_TC, testCase_ID,"Page title are matched");
		}
		else{
			throw new Exception("Page title are not matched");
		}
	}catch (Exception e) {
		if(isSkip!=true){			
			catchBlock(xls_obj, Sheet_TC,e, testCase_ID);
		}
		throw e;
	}
	}
	/**To verify the login user approval count at my documents screen */
	@Test
	public void Demo_TC_002() throws Exception{
		String testCase_ID=getMethodName();
		boolean isSkip=false;
		boolean flag=false;
		
		try{
			isSkip=skip_Test(xls_obj, Sheet_TC, testCase_ID);	
		if(isSkip){
			throw new SkipException("Skip this TestCase");
		}
		
		String TCDesc=obj_TD.getTCDescription(xls_obj, Sheet_TC, testCase_ID);
		startTest(testCase_ID,TCDesc,ClassName);
		
		flag=obj_LPA.verifyApprovalCount(xls_obj, Sheet_TD, testCase_ID);
		
		if(flag){
			tryBlock(xls_obj, Sheet_TC, testCase_ID,"Approval count is matched");
		}
		else{
			throw new Exception("Count not matched");
		}
	}catch (Exception e) {
		if(isSkip!=true){			
			catchBlock(xls_obj, Sheet_TC,e, testCase_ID);
		}
		throw e;
	}
	}
	@AfterClass
	public void close(){
		WebPage.wait(3);
		obj_CM.logout();
	}
}
