package objectRepo;

import org.openqa.selenium.By;

public class OR {
	
			//Login Screen
			public  final By txtEmail=By.id("emailId");
			public  final By txtPassword=By.id("password");
			public  final By btnLogin=By.id("loginSubmit");
			
			//Logout icon
			public final By imgProfile=By.id("headerProfileImage");
			public final By txtLogOut=By.id("logoutLinkP");
			
			//dash board
			
			public final By txtApprCount=By.id("documentDetailsPendingApprovalCount");

}
