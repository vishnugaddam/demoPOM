package actions;

import java.util.Map;
import base.Log;
import objectRepo.OR;
import utility.TestData;
import utility.Xls_Reader;
import webDriver.WebPage;

public class Common_Methods {
	
	OR obj_OR;
	TestData obj_TD;
	
	public Common_Methods(){
		obj_OR=new OR();
		obj_TD=new TestData();
	}
	
	/** To login to Application 
	 * @param UserName
	 * @param Password
	 */
	public void login (String UserName,String Password){
		WebPage.wait(2);
		WebPage.sendKeys(obj_OR.txtEmail, UserName);
		WebPage.wait(2);
		WebPage.sendKeys(obj_OR.txtPassword, Password);	
		WebPage.wait(2);
		WebPage.click(obj_OR.btnLogin);
		WebPage.wait(3);
	}
	/** To logOut from the Application 
	 * @param UserName
	 * @param Password
	 */
	public void logout(){
		WebPage.click(obj_OR.imgProfile);
		WebPage.wait(5);
		WebPage.click(obj_OR.txtLogOut);
	}
	/** To get the current page title and verify expected title**/
	public boolean pageTitleVerification(Xls_Reader xls_obj, String sheet, String testCase_ID){
		Map<String, String> td = obj_TD.getTestData(xls_obj, sheet, testCase_ID);
		boolean flag=false;
		try {
			String actPage=WebPage.getPageTitle();
			String exPage=td.get(obj_TD.col_PageTitle);
			
			if(actPage.contentEquals(exPage)){
				flag=true;
			}else{
				Log.info("page titles are not matched: " +"actPage title : "+actPage);
				flag=false;				
			}
			
		} catch (Exception e) {
			Log.info(e.getMessage());
		}
		return flag;
		
	}

}
