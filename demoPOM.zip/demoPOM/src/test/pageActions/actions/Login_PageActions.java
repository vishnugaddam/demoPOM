package actions;

import java.util.Map;

import org.testng.Assert;

import com.gargoylesoftware.htmlunit.util.DebuggingWebConnection;

import base.Log;
import dashboard.DashBoard_DB;
import objectRepo.OR;
import utility.TestData;
import utility.Xls_Reader;
import webDriver.WebPage;

public class Login_PageActions {
	//login page test case & test data sheets
	public final  String sheet_TestCases="Demo_TC";
	public final  String sheet_TestData="Demo_TestData";
	
	OR obj_OR;
	TestData obj_TD;
	DashBoard_DB obj_DB;

	//constructor part
	public Login_PageActions(){
		obj_OR=new OR();
		obj_TD=new TestData();
		obj_DB=new DashBoard_DB();
	}
	/** To verify the display of approval count at dash board page*/
	public boolean verifyApprovalCount(Xls_Reader xls_obj, String sheet, String testCase_ID){
		Map<String, String> td = obj_TD.getTestData(xls_obj, sheet, testCase_ID);
		String status=td.get(obj_TD.col_Status);
		String userName=td.get(obj_TD.col_UserName);
		boolean flag=false;
		try {
			String actCount=WebPage.getText(obj_OR.txtApprCount);
			String expCount=obj_DB.getDocCount(status, userName);
			
			if(actCount.contentEquals(expCount)){
				flag=true;
			}else{
				Log.info("Approval count is not matched: " +"actCount is : "+actCount);
				flag=false;				
			}
			
		} catch (Exception e) {
			Log.info(e.getMessage());
		}
		return flag;
		
	}
	
	
	
	

}
